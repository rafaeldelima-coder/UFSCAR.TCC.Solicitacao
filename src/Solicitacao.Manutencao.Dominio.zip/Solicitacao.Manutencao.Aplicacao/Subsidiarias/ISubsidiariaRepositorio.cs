﻿using Solicitacao.Manutencao.Dominio.Subisidiarias;

namespace Solicitacao.Manutencao.Aplicacao.Subsidiarias
{
    public interface ISubsidiariaRepositorio:IRepositorio<Subsidiaria>
    {
    }
}
