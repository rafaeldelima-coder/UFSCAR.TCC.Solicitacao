﻿using System.Threading.Tasks;

namespace Solicitacao.Manutencao.Aplicacao
{
    public interface IUnitOfWork
    {
        Task Commit();
    }
}