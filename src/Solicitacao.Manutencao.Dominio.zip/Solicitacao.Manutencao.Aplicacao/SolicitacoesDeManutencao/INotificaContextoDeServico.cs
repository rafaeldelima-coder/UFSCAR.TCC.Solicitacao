﻿using Solicitacao.Manutencao.Dominio.SolicitacoesDeManutencao;
using System.Threading.Tasks;

namespace Solicitacao.Manutencao.Aplicacao.SolicitacoesDeManutencao
{
    public interface INotificaContextoDeServico
    {
        Task Notificar(SolicitacaoDeManutencao solicitacaoDeManutencao);
    }
}
