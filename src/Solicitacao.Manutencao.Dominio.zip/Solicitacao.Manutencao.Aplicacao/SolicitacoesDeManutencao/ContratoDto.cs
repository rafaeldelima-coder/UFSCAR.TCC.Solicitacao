﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solicitacao.Manutencao.Aplicacao.SolicitacoesDeManutencao
{
    public class ContratoDto
    {
        public string Numero { get; set; }
        public string NomeDaTerceirizada { get; set; }
        public string CnpjDaTerceirazada { get; set; }
        public string GestorDoContrato { get; set; }
        public DateTime DataFinalDaVigencia { get; set; }
        public string CnpjDaTerceirizada { get; set; }
    }
}
