﻿using Solicitacao.Manutencao.Dominio.SolicitacoesDeManutencao;

namespace Solicitacao.Manutencao.Aplicacao.SolicitacoesDeManutencao
{
    public interface INotificaReprovacaoParaSolicitante
    {
        void Notificar(SolicitacaoDeManutencao solicitacaoDeManutencao);
    }
}
