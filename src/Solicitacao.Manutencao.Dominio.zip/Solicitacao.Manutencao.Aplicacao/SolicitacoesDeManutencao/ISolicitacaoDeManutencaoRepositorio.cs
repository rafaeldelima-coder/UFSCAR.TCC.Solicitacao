﻿using Solicitacao.Manutencao.Dominio.SolicitacoesDeManutencao;
using System.Collections.Generic;

namespace Solicitacao.Manutencao.Aplicacao.SolicitacoesDeManutencao
{
    public interface ISolicitacaoDeManutencaoRepositorio:IRepositorio<SolicitacaoDeManutencao>
    {
        IEnumerable<SolicitacaoDeManutencao> ObterPendentesDoTipo(
              TipoDeSolicitacaoDeManutencao tipo, string identificadorDaSubsidiaria);
        IEnumerable<SolicitacaoDeManutencao> ObterPendentesDa(string identificadorDaSubsidiaria);
    }
}