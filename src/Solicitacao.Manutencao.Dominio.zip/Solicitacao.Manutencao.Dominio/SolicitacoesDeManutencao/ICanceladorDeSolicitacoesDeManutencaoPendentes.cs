﻿using System.Collections.Generic;

namespace Solicitacao.Manutencao.Dominio.SolicitacoesDeManutencao
{
    public interface ICanceladorDeSolicitacoesDeManutencaoPendentes
    {
        void Cancelar(IEnumerable<SolicitacaoDeManutencao> solicitacoesDeManutencaoPendentes);
    }
}