﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solicitacao.Manutencao.Dominio.SolicitacoesDeManutencao
{
    public enum StatusDaSolicitacao
    {
        Pendente,
        Cancelada,
        Reprovada,
        Aprovada
    }
}
