﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solicitacao.Manutencao.Dominio.SolicitacoesDeManutencao
{
    public enum TipoDeSolicitacaoDeManutencao
    {
        Jardinagem,
        Pintura,
        Eletrica,
        Construção
    }
}
